extends Area2D

signal pickup 
signal hurt   
@export var speed: int = 350


var velocity: Vector2 = Vector2.ZERO


var screensize: Vector2 = Vector2(480, 720)


func _process(delta: float) -> void:
	velocity = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")


	position += velocity * speed * delta

	position.x = clamp(position.x, GLOBAL.BOUNDS.Left, GLOBAL.BOUNDS.Right)
	position.y = clamp(position.y, GLOBAL.BOUNDS.Top, GLOBAL.BOUNDS.Bottom)

	if velocity.length() > 0:
		
		$AnimatedSprite2D.animation = "run"
	else:
		$AnimatedSprite2D.animation = "idle"
	if velocity.x != 0:
		$AnimatedSprite2D.flip_h = velocity.x < 0


func start() -> void:
	
	set_process(true)
	scale = Vector2(2, 2)
	$AnimatedSprite2D.animation = "idle"
	$CollisionShape2D.set_deferred("disabled", false)


func die() -> void:
	$AnimatedSprite2D.animation = "hurt"
	set_process(false)


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("coin"):
		await area.pickup()
		pickup.emit("coin")
	if area.is_in_group("powerup"):
		await area.pickup()
		pickup.emit("powerup")
	if area.is_in_group("obstacles"):
		hurt.emit()
		die()
